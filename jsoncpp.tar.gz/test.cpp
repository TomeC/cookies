#include "json/json.h"
#include <fstream>
#include <string>
#include <iostream>
using namespace std;

int main()
{
	Json::Value root, value;
	Json::FastWriter writer;
	Json::Reader reader;
	string data = "{\"name\":\"haha\", \"age\":15}";
	reader.parse(data, root);
	string str = root["name"].asString();
	cout<<"json: " <<str <<endl;

	return 0;
}
